package br.edu.infnet.vendasApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendasApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
