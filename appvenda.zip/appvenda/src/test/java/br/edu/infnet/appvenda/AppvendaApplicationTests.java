package br.edu.infnet.appvenda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppvendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
